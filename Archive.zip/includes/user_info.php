<?php
  echo "<p>نام کاربری", ": ", $_SESSION["username"] ,"</p><br>" ;
  echo "<p>نام", ": ", $_SESSION["firstname"] ,"</p><br>" ;
  echo "<p>نام خانوادگی", ": ", $_SESSION["lastname"] ,"</p><br>" ;
?>