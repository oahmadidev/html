        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-chart-area"></i>
            نمودار روزانه فاکتور</div>
          <div class="card-body">
            <canvas id="myAreaChart" width="100%" height="30"></canvas>
          </div>
          <div class="card-footer small text-muted">آخرین بروزرسانی دیروز ساعت ۱۳:۲۷</div>
        </div>