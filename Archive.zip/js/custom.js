// jQuery 

$(document).ready(function () {
    $.noCofilict ()
    jQuery('p').mouseenter(function($){

        $(this).hide(600);
    
    
    
    })    
    
});



